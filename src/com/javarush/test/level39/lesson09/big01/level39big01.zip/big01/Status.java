package com.javarush.test.level39.lesson09.big01;

public enum Status {
    OK,
    FAILED,
    ERROR
}
