package com.javarush.test.level39.lesson09.big01;

public enum Event {
    LOGIN,
    DOWNLOAD_PLUGIN,
    WRITE_MESSAGE,
    SOLVE_TASK,
    DONE_TASK
}